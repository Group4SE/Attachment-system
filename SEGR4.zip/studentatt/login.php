<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>LOGIN</title>
    <link rel="stylesheet" type="text/css" href="style.css">
   <section class="s1">
        <div class="main-container">
            <h3 style="text-align: center;">SIGN IN</h3>

            <div class="post-wrapper">


                <div>
                    <div class="post">
                        <img class="thumbnail" src="https://cdn.crispedge.com/43464b.png">
                        <div class="post-preview">
                            <h6 class="post-title">HOST SUPERVISOR</h6>
                            <p class="post-intro">Login to System .</p>
                           <a href="loginhost.php"><button class="cn"> Login</a></button>
                        
                        </div>
                    </div>
                </div>

                    <div>
                    <div class="post">
                        <img class="thumbnail" src="https://htmlcolorcodes.com/assets/images/colors/bright-blue-color-solid-background-1920x1080.png">
                        <div class="post-preview">
                            <h6 class="post-title">STAFF & STUDENTS</h6>
                            <p class="post-intro">Username and Password needed to log in.</p>
                            <a href="loginstudent.php"><button class="cn"> Login</a></button>
                            
                        </div>
                    </div>
                </div>