<!DOCTYPE html>
<html>
<head>
	 <meta charset="utf-8">
    <title>LOGIN PAGE</title>
    <link rel="stylesheet" type="text/css" href="style.css">
   
    </head>
<body>
<div class="container">
		<h1>LOG_IN</h1>
	</div>
<style>
	body{
		background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACoCAMAAABt9SM9AAAAA1BMVEXT09OdeqMBAAAAR0lEQVR4nO3BAQEAAACCIP+vbkhAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAO8GxYgAAb0jQ/cAAAAASUVORK5CYII=');
	}
</style>

            
            <input type="email" name="email" placeholder="Enter username"></br>
            <br><input type="Password" name="" placeholder="Enter Password"></br>

            <br>
            <a href="Student profile.php"><button class="cn"> Login</a></button>


           

 
         </div>
     </div>
    </div>
</div>
<script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script></title>


</body>
</html>